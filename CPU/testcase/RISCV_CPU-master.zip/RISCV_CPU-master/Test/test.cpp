int main() {
  int a = 1;
  int b = 2;
  a = a + b;
  return 0;
}